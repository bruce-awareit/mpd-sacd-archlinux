// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_CONFIG_DEFAULTS_HXX
#define MPD_CONFIG_DEFAULTS_HXX

static constexpr bool DEFAULT_PLAYLIST_SAVE_ABSOLUTE_PATHS = false;

#endif
