// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_CONFIG_DOMAIN_HXX
#define MPD_CONFIG_DOMAIN_HXX

extern const class Domain config_domain;

#endif
