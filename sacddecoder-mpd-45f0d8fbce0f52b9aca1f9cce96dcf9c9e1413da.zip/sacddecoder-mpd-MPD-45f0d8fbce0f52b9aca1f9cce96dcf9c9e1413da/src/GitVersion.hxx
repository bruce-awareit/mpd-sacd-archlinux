// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_GIT_VERSION_HXX
#define MPD_GIT_VERSION_HXX

extern const char GIT_VERSION[];

#endif
