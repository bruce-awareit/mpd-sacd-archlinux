// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_ENCODER_TWOLAME_HXX
#define MPD_ENCODER_TWOLAME_HXX

extern const struct EncoderPlugin twolame_encoder_plugin;

#endif
