// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_ENCODER_VORBIS_H
#define MPD_ENCODER_VORBIS_H

extern const struct EncoderPlugin vorbis_encoder_plugin;

#endif
