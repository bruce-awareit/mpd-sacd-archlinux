// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_ENCODER_WAVE_HXX
#define MPD_ENCODER_WAVE_HXX

extern const struct EncoderPlugin wave_encoder_plugin;

#endif
