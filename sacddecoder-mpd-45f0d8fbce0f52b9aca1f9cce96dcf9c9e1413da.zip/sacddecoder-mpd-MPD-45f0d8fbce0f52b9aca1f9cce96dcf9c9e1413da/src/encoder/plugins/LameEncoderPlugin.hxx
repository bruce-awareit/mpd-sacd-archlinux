// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_ENCODER_LAME_HXX
#define MPD_ENCODER_LAME_HXX

extern const struct EncoderPlugin lame_encoder_plugin;

#endif
