// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_ENCODER_NULL_HXX
#define MPD_ENCODER_NULL_HXX

extern const struct EncoderPlugin null_encoder_plugin;

#endif
