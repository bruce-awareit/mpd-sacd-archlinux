// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_ENCODER_SHINE_HXX
#define MPD_ENCODER_SHINE_HXX

extern const struct EncoderPlugin shine_encoder_plugin;

#endif
