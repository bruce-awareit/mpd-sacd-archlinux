// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_ENCODER_FLAC_HXX
#define MPD_ENCODER_FLAC_HXX

extern const struct EncoderPlugin flac_encoder_plugin;

#endif
