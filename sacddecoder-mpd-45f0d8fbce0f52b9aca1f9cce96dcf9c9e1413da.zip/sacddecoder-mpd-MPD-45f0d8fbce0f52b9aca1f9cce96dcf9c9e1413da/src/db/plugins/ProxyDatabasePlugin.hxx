// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_PROXY_DATABASE_PLUGIN_HXX
#define MPD_PROXY_DATABASE_PLUGIN_HXX

struct DatabasePlugin;

extern const DatabasePlugin proxy_db_plugin;

#endif
