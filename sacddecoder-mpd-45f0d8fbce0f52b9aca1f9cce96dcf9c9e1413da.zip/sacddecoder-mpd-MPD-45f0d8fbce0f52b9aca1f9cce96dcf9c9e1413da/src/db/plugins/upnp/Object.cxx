// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#include "Object.hxx"

/* this destructor exists here just so it won't get inlined */
UPnPDirObject::~UPnPDirObject() noexcept = default;
