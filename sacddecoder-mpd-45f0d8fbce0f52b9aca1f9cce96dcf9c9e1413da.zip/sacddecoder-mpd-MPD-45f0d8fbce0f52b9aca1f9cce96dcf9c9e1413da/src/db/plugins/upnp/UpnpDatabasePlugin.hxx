// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_UPNP_DATABASE_PLUGIN_HXX
#define MPD_UPNP_DATABASE_PLUGIN_HXX

struct DatabasePlugin;

extern const DatabasePlugin upnp_db_plugin;

#endif
