// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_DOMAIN_HXX
#define MPD_DECODER_DOMAIN_HXX

extern const class Domain decoder_domain;

#endif
