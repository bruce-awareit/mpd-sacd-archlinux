// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#include "Domain.hxx"
#include "util/Domain.hxx"

const Domain decoder_domain("decoder");
