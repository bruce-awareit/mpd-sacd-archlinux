// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_PRINT_HXX
#define MPD_DECODER_PRINT_HXX

class Response;

void
decoder_list_print(Response &r);

#endif
