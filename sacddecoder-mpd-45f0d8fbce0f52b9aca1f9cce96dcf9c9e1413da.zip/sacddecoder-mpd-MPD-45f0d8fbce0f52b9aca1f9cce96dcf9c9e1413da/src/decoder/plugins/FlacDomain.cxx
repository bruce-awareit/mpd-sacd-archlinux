// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#include "FlacDomain.hxx"
#include "util/Domain.hxx"

const Domain flac_domain("flac");
