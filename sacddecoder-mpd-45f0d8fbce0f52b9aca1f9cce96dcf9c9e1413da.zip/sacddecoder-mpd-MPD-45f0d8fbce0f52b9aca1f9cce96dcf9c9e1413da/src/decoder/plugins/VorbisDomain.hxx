// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_VORBIS_DOMAIN_HXX
#define MPD_VORBIS_DOMAIN_HXX

class Domain;

extern const Domain vorbis_domain;

#endif
