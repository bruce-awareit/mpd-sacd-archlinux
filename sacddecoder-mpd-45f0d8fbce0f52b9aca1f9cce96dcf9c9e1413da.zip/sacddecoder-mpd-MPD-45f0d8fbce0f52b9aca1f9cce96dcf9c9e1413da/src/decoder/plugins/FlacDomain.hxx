// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_FLAC_DOMAIN_HXX
#define MPD_FLAC_DOMAIN_HXX

extern const class Domain flac_domain;

#endif
