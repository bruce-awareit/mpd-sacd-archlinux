// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_DSF_H
#define MPD_DECODER_DSF_H

extern const struct DecoderPlugin dsf_decoder_plugin;

#endif
