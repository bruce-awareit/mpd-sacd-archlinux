// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_WAVPACK_HXX
#define MPD_DECODER_WAVPACK_HXX

extern const struct DecoderPlugin wavpack_decoder_plugin;

#endif
