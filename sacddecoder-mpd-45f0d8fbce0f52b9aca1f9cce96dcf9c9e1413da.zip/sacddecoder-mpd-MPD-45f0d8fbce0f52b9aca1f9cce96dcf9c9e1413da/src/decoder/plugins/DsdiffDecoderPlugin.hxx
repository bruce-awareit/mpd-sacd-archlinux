// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_DSDIFF_H
#define MPD_DECODER_DSDIFF_H

extern const struct DecoderPlugin dsdiff_decoder_plugin;

#endif
