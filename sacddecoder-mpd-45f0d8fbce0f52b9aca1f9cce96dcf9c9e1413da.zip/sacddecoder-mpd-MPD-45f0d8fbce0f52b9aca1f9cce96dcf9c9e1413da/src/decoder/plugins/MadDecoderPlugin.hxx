// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_MAD_HXX
#define MPD_DECODER_MAD_HXX

extern const struct DecoderPlugin mad_decoder_plugin;

#endif
