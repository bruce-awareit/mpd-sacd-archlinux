// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_FFMPEG_HXX
#define MPD_DECODER_FFMPEG_HXX

extern const struct DecoderPlugin ffmpeg_decoder_plugin;

#endif
