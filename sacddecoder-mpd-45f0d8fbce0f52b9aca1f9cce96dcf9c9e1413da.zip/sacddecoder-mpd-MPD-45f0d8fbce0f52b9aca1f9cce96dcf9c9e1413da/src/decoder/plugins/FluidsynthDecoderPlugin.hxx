// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_FLUIDSYNTH_HXX
#define MPD_DECODER_FLUIDSYNTH_HXX

extern const struct DecoderPlugin fluidsynth_decoder_plugin;

#endif
