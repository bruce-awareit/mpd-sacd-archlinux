// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_OPENMPT_HXX
#define MPD_DECODER_OPENMPT_HXX

extern const struct DecoderPlugin openmpt_decoder_plugin;

#endif
