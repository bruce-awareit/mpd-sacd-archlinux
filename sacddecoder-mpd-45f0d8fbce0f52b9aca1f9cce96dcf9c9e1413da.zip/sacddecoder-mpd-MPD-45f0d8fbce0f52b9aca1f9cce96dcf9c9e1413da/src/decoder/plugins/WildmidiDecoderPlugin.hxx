// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_WILDMIDI_HXX
#define MPD_DECODER_WILDMIDI_HXX

extern const struct DecoderPlugin wildmidi_decoder_plugin;

#endif
