// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_DECODER_MIKMOD_HXX
#define MPD_DECODER_MIKMOD_HXX

extern const struct DecoderPlugin mikmod_decoder_plugin;

#endif
