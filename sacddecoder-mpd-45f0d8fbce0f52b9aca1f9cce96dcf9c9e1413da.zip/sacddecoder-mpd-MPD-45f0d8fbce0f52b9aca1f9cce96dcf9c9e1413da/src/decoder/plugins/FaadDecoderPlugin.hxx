// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#ifndef MPD_FAAD_DECODER_PLUGIN_HXX
#define MPD_FAAD_DECODER_PLUGIN_HXX

extern const struct DecoderPlugin faad_decoder_plugin;

#endif
