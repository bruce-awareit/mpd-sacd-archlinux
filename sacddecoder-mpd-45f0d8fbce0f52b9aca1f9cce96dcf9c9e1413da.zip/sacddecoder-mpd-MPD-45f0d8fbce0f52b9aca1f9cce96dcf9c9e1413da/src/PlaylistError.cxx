// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright The Music Player Daemon Project

#include "PlaylistError.hxx"
#include "util/Domain.hxx"

const Domain playlist_domain("playlist");
