Music Player Daemon
===================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   user
   plugins
   developer
   client
   protocol

.. toctree::
   :maxdepth: 1
   :caption: man pages:

   mpd.1
   mpd.conf.5

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
