MPD for Android Privacy Policy
==============================

Music Player Daemon is an open source project currently maintained by
`Max Kellermann <mailto:max.kellermann+googleplay@gmail.com>`__.

Music Player Daemon does not access, collect, use or share any
personal or sensitive user data.
